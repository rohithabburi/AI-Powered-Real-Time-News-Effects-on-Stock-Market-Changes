# -*- coding: utf-8 -*-
"""
AI-Powered Real-Time News Effects on Stock Market Changes
Airflow DAG with three pipelines: Data_preprocessing, Model_Training, Stock_prediction_from_news.
Runs every 5 minutes, trains for 10 epochs, ensures outputs are not empty.
Uses /opt/airflow/dags/ for CSVs and /opt/airflow/outputs/ for outputs, per Docker volumes.
"""

from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info(f"DAG file loaded from: {__file__}")

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
}

def data_preprocessing_task(ti=None):
    """Pipeline 1: Load, preprocess, and save news and stock data."""
    import pandas as pd
    import re
    import nltk
    from nltk.tokenize import word_tokenize
    from nltk.corpus import stopwords
    from nltk.stem import WordNetLemmatizer
    from sklearn.preprocessing import MinMaxScaler
    from joblib import dump
    from datetime import datetime

    # Define paths based on Docker volume mappings
    INPUT_DIR = '/opt/airflow/dags'
    OUTPUT_DIR = '/opt/airflow/outputs'
    NEWS_FILE = os.path.join(INPUT_DIR, 'News_data_updated.csv')
    STOCK_FILE = os.path.join(INPUT_DIR, 'stock_data.csv')

    logger.info(f"Starting Data_preprocessing task at {datetime.now()}")
    logger.info(f"Input files: {NEWS_FILE}, {STOCK_FILE}")
    logger.info(f"Output directory: {OUTPUT_DIR}")
    logger.info(f"Listing /opt/airflow/dags/: {os.listdir(INPUT_DIR)}")

    try:
        nltk.download('punkt', quiet=True)
        nltk.download('stopwords', quiet=True)
        nltk.download('wordnet', quiet=True)
    except Exception as e:
        logger.error(f"Failed to download NLTK data: {str(e)}")
        raise

    def load_and_preprocess_data(news_file=NEWS_FILE, stock_file=STOCK_FILE):
        logger.info("Loading and preprocessing data...")
        if not os.path.exists(news_file):
            logger.error(f"News file not found: {news_file}")
            raise FileNotFoundError(f"News file not found: {news_file}")
        if not os.path.exists(stock_file):
            logger.error(f"Stock file not found: {stock_file}")
            raise FileNotFoundError(f"Stock file not found: {stock_file}")

        try:
            new_data = pd.read_csv(news_file)
            stock_data = pd.read_csv(stock_file)
        except Exception as e:
            logger.error(f"Error reading CSV files: {str(e)}")
            raise

        if new_data.empty or stock_data.empty:
            logger.error("One or both input files are empty")
            raise ValueError("Input data is empty")

        new_data["Article Time"] = pd.to_datetime(new_data["Article Time"], errors='coerce').dt.tz_localize(None).dt.floor("min")
        stock_data["Timestamp"] = pd.to_datetime(stock_data["Timestamp"], errors='coerce').dt.floor("min")
        
        merged_data = pd.merge_asof(
            new_data.sort_values("Article Time"),
            stock_data.sort_values("Timestamp"),
            left_on="Article Time",
            right_on="Timestamp",
            by="Ticker",
            tolerance=pd.Timedelta("10min"),
            direction="nearest"
        ).dropna()
        
        if merged_data.empty:
            logger.error("Merged data is empty after preprocessing")
            raise ValueError("Merged data is empty after preprocessing")
        
        merged_data = merged_data[['Ticker', 'Title', 'Timestamp', 'Open', 'High', 'Low', 'Close']]
        merged_data = merged_data.sort_values(by="Timestamp", ascending=False)
        logger.info(f"Merged data shape: {merged_data.shape}")
        return merged_data

    def clean_text(text):
        stop_words = set(stopwords.words('english'))
        lemmatizer = WordNetLemmatizer()
        if not isinstance(text, str):
            return ""
        text = text.lower()
        text = re.sub(r'\d+', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        text = re.sub(r'[^\w\s]', '', text)
        words = word_tokenize(text)
        words = [lemmatizer.lemmatize(word) for word in words if word not in stop_words]
        return " ".join(words)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Load and preprocess
    merged_data = load_and_preprocess_data()

    # Clean titles
    merged_data['cleaned_title'] = merged_data['Title'].apply(clean_text)

    # Scale features
    scaler_inputs = MinMaxScaler()
    merged_data[['Open', 'High', 'Low']] = scaler_inputs.fit_transform(merged_data[['Open', 'High', 'Low']])
    scaler_target = MinMaxScaler()
    merged_data['Close'] = scaler_target.fit_transform(merged_data[['Close']])

    # Save outputs
    data_path = os.path.join(OUTPUT_DIR, f"preprocessed_data_{timestamp}.csv")
    scaler_inputs_path = os.path.join(OUTPUT_DIR, f"scaler_inputs_{timestamp}.joblib")
    scaler_target_path = os.path.join(OUTPUT_DIR, f"scaler_target_{timestamp}.joblib")
    
    merged_data.to_csv(data_path, index=False)
    dump(scaler_inputs, scaler_inputs_path)
    dump(scaler_target, scaler_target_path)

    # Validate outputs
    for path in [data_path, scaler_inputs_path, scaler_target_path]:
        if not os.path.exists(path) or os.path.getsize(path) == 0:
            logger.error(f"Output file is missing or empty: {path}")
            raise ValueError(f"Output file is missing or empty: {path}")

    logger.info(f"Preprocessed data saved to {data_path}")
    logger.info(f"Scalers saved to {scaler_inputs_path}, {scaler_target_path}")

    # Push file paths to XCom
    ti.xcom_push(key='data_path', value=data_path)
    ti.xcom_push(key='scaler_inputs_path', value=scaler_inputs_path)
    ti.xcom_push(key='scaler_target_path', value=scaler_target_path)

def model_training_task(ti=None):
    """Pipeline 2: Train model for 10 epochs, track losses, and save outputs."""
    import pandas as pd
    import numpy as np
    import torch
    import torch.nn as nn
    import torch.optim as optim
    from torch.utils.data import DataLoader, TensorDataset
    from transformers import BertTokenizer, BertModel
    from sklearn.model_selection import train_test_split
    import matplotlib.pyplot as plt
    from datetime import datetime

    OUTPUT_DIR = '/opt/airflow/outputs'
    logger.info(f"Starting Model_Training task at {datetime.now()}")
    np.random.seed(42)

    class NewsAndStockPredictionModel(nn.Module):
        def __init__(self, stock_input_size, bert_input_size, hidden_size, output_size):
            super(NewsAndStockPredictionModel, self).__init__()
            self.total_input_size = stock_input_size + bert_input_size
            self.fc1 = nn.Linear(self.total_input_size, hidden_size)
            self.bn1 = nn.BatchNorm1d(hidden_size)
            self.fc2 = nn.Linear(hidden_size, hidden_size // 2)
            self.bn2 = nn.BatchNorm1d(hidden_size // 2)
            self.fc3 = nn.Linear(hidden_size // 2, output_size)
            self.relu = nn.ReLU()
            self.dropout = nn.Dropout(0.2)

        def forward(self, x):
            out = self.fc1(x)
            out = self.bn1(out)
            out = self.relu(out)
            out = self.dropout(out)
            out = self.fc2(out)
            out = self.bn2(out)
            out = self.relu(out)
            out = self.dropout(out)
            out = self.fc3(out)
            return out

    def get_bert_embedding(text, tokenizer, bert_model):
        tokens = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512)
        with torch.no_grad():
            output = bert_model(**tokens)
        return output.last_hidden_state.mean(dim=1).squeeze().numpy()

    def train_model(model, train_loader, val_loader, device, epochs=10, timestamp=None):
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.0001)
        train_losses = []
        val_losses = []

        logger.info("Starting model training for 10 epochs...")
        for epoch in range(epochs):
            model.train()
            train_loss = 0
            for batch_X, batch_y in train_loader:
                batch_X, batch_y = batch_X.to(device), batch_y.to(device)
                optimizer.zero_grad()
                predictions = model(batch_X)
                loss = criterion(predictions, batch_y)
                loss.backward()
                optimizer.step()
                train_loss += loss.item()

            avg_train_loss = train_loss / len(train_loader)
            train_losses.append(avg_train_loss)

            model.eval()
            val_loss = 0
            with torch.no_grad():
                for batch_X, batch_y in val_loader:
                    batch_X, batch_y = batch_X.to(device), batch_y.to(device)
                    predictions = model(batch_X)
                    loss = criterion(predictions, batch_y)
                    val_loss += loss.item()

            avg_val_loss = val_loss / len(val_loader)
            val_losses.append(avg_val_loss)

            logger.info(f"Epoch {epoch+1}/{epochs}, Train Loss: {avg_train_loss:.6f}, Val Loss: {avg_val_loss:.6f}")

        # Save model
        model_path = os.path.join(OUTPUT_DIR, f"model_{timestamp}.pth")
        torch.save(model.state_dict(), model_path)

        # Save losses to CSV
        losses_df = pd.DataFrame({
            'Epoch': range(1, len(train_losses) + 1),
            'Train_Loss': train_losses,
            'Val_Loss': val_losses
        })
        losses_csv_path = os.path.join(OUTPUT_DIR, f"losses_{timestamp}.csv")
        losses_df.to_csv(losses_csv_path, index=False)

        # Plot and save loss graph
        plt.figure(figsize=(10, 6))
        plt.plot(train_losses, color='blue', label='Train Loss')
        plt.plot(val_losses, color='red', linestyle='--', label='Validation Loss')
        plt.xlabel('Epoch')
        plt.ylabel('Loss (MSE)')
        plt.title('Training vs Validation Loss (10 Epochs)')
        plt.legend()
        plt.grid(True)
        loss_plot_path = os.path.join(OUTPUT_DIR, f"loss_plot_{timestamp}.png")
        plt.savefig(loss_plot_path)
        plt.close()

        # Validate outputs
        for path in [model_path, losses_csv_path, loss_plot_path]:
            if not os.path.exists(path) or os.path.getsize(path) == 0:
                logger.error(f"Output file is missing or empty: {path}")
                raise ValueError(f"Output file is missing or empty: {path}")

        logger.info(f"Model saved to {model_path}")
        logger.info(f"Losses saved to {losses_csv_path}")
        logger.info(f"Loss plot saved to {loss_plot_path}")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Pull preprocessed data path from XCom
    data_path = ti.xcom_pull(key='data_path', task_ids='Data_preprocessing')
    if not data_path or not os.path.exists(data_path):
        logger.error(f"Preprocessed data not found: {data_path}")
        raise FileNotFoundError(f"Preprocessed data not found: {data_path}")

    # Load data
    data = pd.read_csv(data_path)
    if data.empty:
        logger.error(f"Preprocessed data is empty: {data_path}")
        raise ValueError(f"Preprocessed data is empty: {data_path}")
    logger.info(f"Loaded preprocessed data from {data_path}")

    # Initialize BERT
    try:
        tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        bert_model = BertModel.from_pretrained('bert-base-uncased')
    except Exception as e:
        logger.error(f"Failed to load BERT model: {str(e)}")
        raise

    # Generate BERT embeddings
    data['bert_embedding'] = data['cleaned_title'].apply(lambda x: get_bert_embedding(x, tokenizer, bert_model))

    # Prepare features
    stock_features = data[['Open', 'High', 'Low']].values
    bert_embeddings = np.stack(data['bert_embedding'].values)
    X = np.concatenate([stock_features, bert_embeddings], axis=1)
    y = data['Close'].values

    # Split data
    X_temp, X_test, y_temp, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    X_train, X_val, y_train, y_val = train_test_split(X_temp, y_temp, test_size=0.25, random_state=42)

    # Create data loaders
    train_dataset = TensorDataset(torch.tensor(X_train, dtype=torch.float32), torch.tensor(y_train, dtype=torch.float32).view(-1, 1))
    val_dataset = TensorDataset(torch.tensor(X_val, dtype=torch.float32), torch.tensor(y_val, dtype=torch.float32).view(-1, 1))
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=32)

    # Initialize model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = NewsAndStockPredictionModel(stock_input_size=3, bert_input_size=768, hidden_size=128, output_size=1).to(device)

    # Train model
    train_model(model, train_loader, val_loader, device, epochs=10, timestamp=timestamp)

    # Push model path to XCom
    model_path = os.path.join(OUTPUT_DIR, f"model_{timestamp}.pth")
    ti.xcom_push(key='model_path', value=model_path)

    logger.info(f"Training completed at {datetime.now()}")

def stock_prediction_from_news_task(ti=None):
    """Pipeline 3: Predict stock prices for new headlines."""
    import pandas as pd
    import numpy as np
    import torch
    import torch.nn as nn
    from transformers import BertTokenizer, BertModel
    from joblib import load
    from datetime import datetime

    OUTPUT_DIR = '/opt/airflow/outputs'
    logger.info(f"Starting Stock_prediction_from_news task at {datetime.now()}")

    class NewsAndStockPredictionModel(nn.Module):
        def __init__(self, stock_input_size, bert_input_size, hidden_size, output_size):
            super(NewsAndStockPredictionModel, self).__init__()
            self.total_input_size = stock_input_size + bert_input_size
            self.fc1 = nn.Linear(self.total_input_size, hidden_size)
            self.bn1 = nn.BatchNorm1d(hidden_size)
            self.fc2 = nn.Linear(hidden_size, hidden_size // 2)
            self.bn2 = nn.BatchNorm1d(hidden_size // 2)
            self.fc3 = nn.Linear(hidden_size // 2, output_size)
            self.relu = nn.ReLU()
            self.dropout = nn.Dropout(0.2)

        def forward(self, x):
            out = self.fc1(x)
            out = self.bn1(out)
            out = self.relu(out)
            out = self.dropout(out)
            out = self.fc2(out)
            out = self.bn2(out)
            out = self.relu(out)
            out = self.dropout(out)
            out = self.fc3(out)
            return out

    def get_bert_embedding(text, tokenizer, bert_model):
        tokens = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512)
        with torch.no_grad():
            output = bert_model(**tokens)
        return output.last_hidden_state.mean(dim=1).squeeze().numpy()

    def predict_new_headlines(model, headlines, scaler_inputs, scaler_target, tokenizer, bert_model, device, timestamp):
        placeholder_stock_data = np.array([[0.0, 0.0, 0.0]])
        predictions = []
        logger.info("Predicted Close Prices for New Headlines:")
        logger.info("-" * 50)
        for headline in headlines:
            bert_embedding = get_bert_embedding(headline, tokenizer, bert_model)
            features = np.concatenate([scaler_inputs.transform(placeholder_stock_data), bert_embedding.reshape(1, -1)], axis=1)
            with torch.no_grad():
                pred_tensor = torch.tensor(features, dtype=torch.float32).to(device)
                pred_scaled = model(pred_tensor).cpu().numpy()[0][0]
                pred_actual = scaler_target.inverse_transform([[pred_scaled]])[0][0]
                logger.info(f"Headline: '{headline}'")
                logger.info(f"Predicted Close Price: ${pred_actual:.2f}")
                logger.info("-" * 50)
                predictions.append({'Headline': headline, 'Predicted Close Price': pred_actual})
        predictions_path = os.path.join(OUTPUT_DIR, f"predictions_{timestamp}.csv")
        pd.DataFrame(predictions).to_csv(predictions_path, index=False)

        # Validate output
        if not os.path.exists(predictions_path) or os.path.getsize(predictions_path) == 0:
            logger.error(f"Predictions file is missing or empty: {predictions_path}")
            raise ValueError(f"Predictions file is missing or empty: {predictions_path}")
        logger.info(f"Predictions saved to {predictions_path}")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Pull file paths from XCom
    model_path = ti.xcom_pull(key='model_path', task_ids='Model_Training')
    scaler_inputs_path = ti.xcom_pull(key='scaler_inputs_path', task_ids='Data_preprocessing')
    scaler_target_path = ti.xcom_pull(key='scaler_target_path', task_ids='Data_preprocessing')

    if not (model_path and scaler_inputs_path and scaler_target_path):
        logger.error("Required files (model or scalers) not found")
        raise ValueError("Required files (model or scalers) not found")

    # Load scalers
    try:
        scaler_inputs = load(scaler_inputs_path)
        scaler_target = load(scaler_target_path)
    except Exception as e:
        logger.error(f"Failed to load scalers: {str(e)}")
        raise
    logger.info(f"Loaded scalers from {scaler_inputs_path}, {scaler_target_path}")

    # Initialize model
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = NewsAndStockPredictionModel(stock_input_size=3, bert_input_size=768, hidden_size=128, output_size=1).to(device)
    try:
        model.load_state_dict(torch.load(model_path))
    except Exception as e:
        logger.error(f"Failed to load model: {str(e)}")
        raise
    model.eval()
    logger.info(f"Loaded model from {model_path}")

    # Initialize BERT
    try:
        tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        bert_model = BertModel.from_pretrained('bert-base-uncased')
    except Exception as e:
        logger.error(f"Failed to load BERT model: {str(e)}")
        raise

    # Predict on new headlines
    headlines = [
        "Company reports strong earnings",
        "Stock market crashes due to economic downturn",
        "Tech giant announces major layoffs",
        "New product launch boosts company shares",
        "Regulatory fines hit company profits hard"
    ]
    predict_new_headlines(model, headlines, scaler_inputs, scaler_target, tokenizer, bert_model, device, timestamp)

    logger.info(f"Prediction completed at {datetime.now()}")

with DAG(
    dag_id='stock_news_prediction',
    start_date=datetime(2025, 4, 11),
    schedule_interval="*/2 * * * *",  # Every 2 minutes
    catchup=False,
    max_active_runs=1,
    default_args=default_args
) as dag:
    data_preprocessing = PythonOperator(
        task_id='Data_preprocessing',
        python_callable=data_preprocessing_task,
    )

    model_training = PythonOperator(
        task_id='Model_Training',
        python_callable=model_training_task,
    )

    stock_prediction = PythonOperator(
        task_id='Stock_prediction_from_news',
        python_callable=stock_prediction_from_news_task,
    )

    # Set task dependencies
    data_preprocessing >> model_training >> stock_prediction